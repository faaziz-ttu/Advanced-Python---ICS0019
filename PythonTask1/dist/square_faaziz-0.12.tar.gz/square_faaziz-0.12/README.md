#'square_faaziz'

The 'square-faaziz' is a simple module to calculate square formula of (a + b) ^ 2