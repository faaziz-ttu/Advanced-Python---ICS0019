class SquareFunction:
    def __init__(self):
        self.sum = None

    def square_form(self, a, b):
        self.sum = (a + b) * (a + b)
        return self.sum
